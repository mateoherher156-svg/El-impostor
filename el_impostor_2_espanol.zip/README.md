# EL IMPOSTOR 2.0

Juego multijugador en español con salas, QR, palabras secretas, votación y sonidos originales sintetizados en el navegador.

## Ejecutarlo
Necesitas Node.js 18 o superior:
1. Descomprime el ZIP.
2. Abre una terminal en la carpeta.
3. Ejecuta `npm install`
4. Ejecuta `npm start`
5. Abre `http://localhost:3000`

## Publicarlo gratis en Render
1. Sube estos archivos a un repositorio GitHub.
2. En Render crea un servicio **New + → Web Service** y conecta ese repositorio.
3. Render detectará `render.yaml`; si pregunta, usa Build Command `npm install` y Start Command `npm start`.
4. Cuando termine el despliegue, abre la URL HTTPS que te dé Render. Ese será el enlace para compartir.
5. Crea una sala desde esa URL; el QR llevará a tus amigos a la misma sala.

El servidor necesita soporte WebSocket (Render Web Services lo admite). El QR usa una pequeña librería de CDN, por lo que el dispositivo necesita Internet para cargarla.

## Reglas
- Mínimo 3 jugadores, máximo 20 por sala.
- El anfitrión crea sala, configura categoría e impostores y empieza.
- Cada jugador consulta su rol en privado.
- El anfitrión inicia la votación cuando acaban las pistas.
- Cada jugador vota una vez; al votar todos, se muestran resultados.
- Las salas viven en memoria y se borran al reiniciar el servidor.

## Sonido
Los efectos y la melodía son generados por Web Audio en el propio navegador. Pulsa «Sonido: OFF» para activarlos. Los navegadores requieren una interacción del usuario antes de reproducir audio.
