const http=require('http'),fs=require('fs'),path=require('path'),{WebSocketServer}=require('ws');
const PORT=process.env.PORT||3000;
const words={animals:['Elefante','Pingüino','Delfín','Jirafa','Pulpo','Canguro','Mariposa','Cocodrilo','Erizo','Flamenco'],food:['Pizza','Sushi','Tortitas','Sandía','Taco','Chocolate','Palomitas','Lasaña','Fresa','Hamburguesa'],places:['Aeropuerto','Playa','Museo','Hospital','Biblioteca','Volcán','Cine','Acuario','Castillo','Restaurante'],objects:['Paraguas','Cepillo de dientes','Mochila','Espejo','Gafas de sol','Mando','Vela','Maleta','Teclado','Bicicleta'],sports:['Baloncesto','Tenis','Surf','Fútbol','Voleibol','Boxeo','Esquí','Golf','Patinaje','Natación']};
const mixed=Object.values(words).flat(),rooms=new Map();
const server=http.createServer((req,res)=>{let f=path.join(__dirname,'public','index.html');fs.readFile(f,(e,d)=>{if(e){res.writeHead(500);return res.end('No se pudo cargar el juego.')}res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store'});res.end(d)})});
const wss=new WebSocketServer({server});
const send=(ws,o)=>{if(ws.readyState===1)ws.send(JSON.stringify(o))},err=(ws,message)=>send(ws,{type:'error',message});
function snapshot(r){return {phase:r.phase,hostId:r.hostId,players:[...r.players.values()].map(p=>({id:p.id,name:p.name})),impostorCount:r.impostorCount||1,votesCount:Object.keys(r.votes||{}).length,word:r.phase==='results'?r.word:undefined,impostorIds:r.phase==='results'?r.impostorIds:undefined,impostorsCaught:r.phase==='results'?r.impostorsCaught:undefined}}
function broadcast(r){const s=snapshot(r);for(const p of r.players.values())send(p.ws,{type:'state',state:s})}
function newCode(){let c;do{c=Math.random().toString(36).slice(2,7).toUpperCase()}while(rooms.has(c));return c}
function finishVotes(r){const ids=[...r.players.keys()];if(ids.some(id=>!r.votes[id]))return;const tally={};Object.values(r.votes).forEach(id=>tally[id]=(tally[id]||0)+1);const max=Math.max(...Object.values(tally));const top=Object.keys(tally).filter(id=>tally[id]===max);r.impostorsCaught=top.length===1&&r.impostorIds.includes(top[0]);r.phase='results';broadcast(r)}
function add(r,ws,id,name){name=String(name||'').trim().slice(0,18);if(!name)return err(ws,'Escribe tu nombre.');if([...r.players.values()].some(p=>p.name.toLowerCase()===name.toLowerCase()))return err(ws,'Ese nombre ya está en uso en esta sala.');r.players.set(id,{id,name,ws});ws.room=r.code;send(ws,{type:'joined',room:r.code,playerId:id,isHost:id===r.hostId});broadcast(r)}
wss.on('connection',ws=>{const id=Math.random().toString(36).slice(2,11);ws.id=id;ws.room=null;
ws.on('message',raw=>{let m;try{m=JSON.parse(raw)}catch{return}
if(m.type==='create'){if(ws.room)return;const code=newCode(),r={code,hostId:id,players:new Map(),phase:'lobby',votes:{}};rooms.set(code,r);add(r,ws,id,m.name);return}
if(m.type==='join'){if(ws.room)return;const r=rooms.get(String(m.room||'').toUpperCase());if(!r)return err(ws,'No se encuentra la sala. Comprueba el código.');if(r.phase!=='lobby')return err(ws,'La partida ya ha empezado.');if(r.players.size>=20)return err(ws,'La sala está llena.');add(r,ws,id,m.name);return}
const r=rooms.get(ws.room);if(!r)return;
if(m.type==='start'){if(id!==r.hostId||r.phase!=='lobby')return;if(r.players.size<3)return err(ws,'Se necesitan al menos 3 jugadores.');const n=Math.max(1,Math.min(Number(m.impostors)||1,r.players.size-1));r.impostorCount=n;const pool=m.category==='mixed'?mixed:(words[m.category]||mixed);r.word=pool[Math.floor(Math.random()*pool.length)];r.impostorIds=[...r.players.keys()].sort(()=>Math.random()-.5).slice(0,n);r.phase='playing';r.votes={};for(const [pid,p] of r.players)send(p.ws,{type:'role',isImpostor:r.impostorIds.includes(pid),word:r.impostorIds.includes(pid)?null:r.word});broadcast(r)}
if(m.type==='getRole'&&r.phase==='playing')send(ws,{type:'role',isImpostor:r.impostorIds.includes(id),word:r.impostorIds.includes(id)?null:r.word});
if(m.type==='beginVote'&&id===r.hostId&&r.phase==='playing'){r.phase='voting';r.votes={};broadcast(r)}
if(m.type==='vote'&&r.phase==='voting'&&r.players.has(m.targetId)&&m.targetId!==id&&!r.votes[id]){r.votes[id]=m.targetId;const count=Object.keys(r.votes).length;for(const p of r.players.values())send(p.ws,{type:'voteUpdate',count,total:r.players.size});finishVotes(r)}
if(m.type==='again'&&id===r.hostId&&r.phase==='results'){r.phase='lobby';delete r.word;delete r.impostorIds;delete r.impostorsCaught;r.votes={};broadcast(r)}
});
ws.on('close',()=>{const r=rooms.get(ws.room);if(!r)return;r.players.delete(id);if(!r.players.size){rooms.delete(r.code);return}if(r.hostId===id)r.hostId=r.players.keys().next().value;if(r.phase==='voting')finishVotes(r);broadcast(r)})});
server.listen(PORT,'0.0.0.0',()=>console.log(`EL IMPOSTOR 2.0 escuchando en el puerto ${PORT}`));
